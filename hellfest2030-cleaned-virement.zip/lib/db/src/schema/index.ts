// Export your models here. Add one export per file
// export * from "./posts";
//
// Each model/table should ideally be split into different files.
// Each model/table should define a Drizzle table, insert schema, and types:
//
//   import { pgTable, text, serial } from "drizzle-orm/pg-core";
//   import { createInsertSchema } from "drizzle-zod";
//   import { z } from "zod/v4";
//
//   export const postsTable = pgTable("posts", {
//     id: serial("id").primaryKey(),
//     title: text("title").notNull(),
//   });
//
//   export const insertPostSchema = createInsertSchema(postsTable).omit({ id: true });
//   export type InsertPost = z.infer<typeof insertPostSchema>;
//   export type Post = typeof postsTable.$inferSelect;

import { relations } from "drizzle-orm";
import {
  integer,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

export const hellfestOrders = pgTable(
  "hellfest_orders",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    paymentReference: text("payment_reference").notNull().unique(),
    customerName: text("customer_name").notNull(),
    email: text("email").notNull(),
    phone: text("phone").notNull(),
    address: text("address").notNull(),
    birthDate: text("birth_date"),
    product: text("product").notNull(),
    quantity: integer("quantity").notNull(),
    unitPrice: text("unit_price"),
    totalPrice: text("total_price").notNull(),
    status: text("status").notNull().default("AWAITING_BANK_TRANSFER"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => ({
    paymentReferenceIdx: uniqueIndex("hellfest_orders_payment_reference_idx").on(
      table.paymentReference,
    ),
  }),
);

export const hellfestPayments = pgTable(
  "hellfest_payments",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    orderId: uuid("order_id")
      .notNull()
      .references(() => hellfestOrders.id),
    paymentReference: text("payment_reference").notNull(),
    clientName: text("client_name").notNull(),
    amount: text("amount").notNull(),
    proofObjectPath: text("proof_object_path").notNull(),
    proofFileName: text("proof_file_name").notNull(),
    proofContentType: text("proof_content_type").notNull(),
    proofSize: integer("proof_size").notNull(),
    status: text("status").notNull().default("PENDING_PAYMENT_VERIFICATION"),
    submittedAt: timestamp("submitted_at", { withTimezone: true }).defaultNow().notNull(),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
    reviewNote: text("review_note"),
  },
  (table) => ({
    oneProofPerOrderIdx: uniqueIndex("hellfest_payments_one_proof_per_order_idx").on(
      table.orderId,
    ),
  }),
);

export const hellfestOrderRelations = relations(hellfestOrders, ({ one }) => ({
  payment: one(hellfestPayments),
}));

export const hellfestPaymentRelations = relations(hellfestPayments, ({ one }) => ({
  order: one(hellfestOrders, {
    fields: [hellfestPayments.orderId],
    references: [hellfestOrders.id],
  }),
}));

export type HellfestOrder = typeof hellfestOrders.$inferSelect;
export type HellfestPayment = typeof hellfestPayments.$inferSelect;