# Hellfest Revente — paiement par virement

## 1. Installation

Pré-requis :

- Node.js 20 ou supérieur
- pnpm 10 ou supérieur
- une base PostgreSQL Replit ou PostgreSQL compatible
- un bucket App Storage Replit

Installation :

```bash
pnpm install
pnpm run typecheck:libs
pnpm --filter @workspace/api-server run typecheck
pnpm --filter @workspace/hellfest-revente run build
```

## 2. Variables serveur

Les variables suivantes doivent être configurées dans les Secrets ou variables d’environnement du serveur :

- `DATABASE_URL`
- `SESSION_SECRET`
- `TELEGRAM_BOT_TOKEN`
- `TELEGRAM_CHAT_ID`
- `PRIVATE_OBJECT_DIR`
- `PUBLIC_OBJECT_SEARCH_PATHS`

Les secrets Telegram et la connexion PostgreSQL ne doivent jamais être ajoutés aux fichiers publics.

## 3. Démarrage

En développement :

```bash
pnpm --filter @workspace/api-server run dev
pnpm --filter @workspace/hellfest-revente run dev
```

Les workflows Replit du projet utilisent déjà les commandes adaptées et injectent automatiquement le port.

## 4. Changer les coordonnées du virement

Modifier uniquement ce fichier :

`artifacts/hellfest-revente/public/bank-config.js`

Exemple :

```js
window.HfBankConfig = Object.freeze({
  beneficiary: "Nom du bénéficiaire",
  iban: "FRXXXXXXXXXXXXXXXXXXXXXXXXXXX",
  bic: "XXXXXXXXXXX",
  accountNumber: "",
  rib: "",
});
```

Le site affiche uniquement :

- le nom du bénéficiaire ;
- l’IBAN ;
- le BIC ;
- la référence unique de la commande.

Le nom de la banque, le numéro de compte et le RIB ne sont pas affichés.

Après toute modification :

```bash
pnpm --filter @workspace/hellfest-revente run build
```

Puis redémarrer le workflow web ou republier le projet.

## 5. Fonctionnement du paiement

1. Le client valide sa commande.
2. Une référence unique est générée.
3. Le client effectue le virement avec cette référence.
4. Le client téléverse un justificatif JPG, PNG ou PDF de 5 Mo maximum.
5. La preuve est stockée dans App Storage et associée à la commande.
6. Telegram reçoit le justificatif avec les boutons de validation et de refus.
7. Le statut de la commande est mis à jour après l’action Telegram.

## 6. Contrôles rapides

```bash
curl http://localhost:8080/api/healthz
curl -X POST http://localhost:8080/api/orders \
  -H "Content-Type: application/json" \
  -d '{}'
```

Le premier appel doit répondre avec `{"status":"ok"}`. Le second doit refuser la commande vide avec une erreur HTTP 400.