import { and, eq } from "drizzle-orm";
import { Router, type IRouter, type Request, type Response } from "express";
import { randomUUID } from "node:crypto";
import { hellfestOrders, hellfestPayments, db } from "@workspace/db";
import { ObjectStorageService } from "../lib/objectStorage";
import { logger } from "../lib/logger";

const router: IRouter = Router();
const objectStorageService = new ObjectStorageService();
const MAX_PROOF_SIZE = 5 * 1024 * 1024;
const ALLOWED_PROOF_TYPES = new Set(["image/jpeg", "image/png", "application/pdf"]);
const BOT_TOKEN = process.env["TELEGRAM_BOT_TOKEN"];
const CHAT_ID = process.env["TELEGRAM_CHAT_ID"];

type OrderPayload = {
  nom: string;
  email: string;
  tel: string;
  adresse: string;
  jour?: string;
  mois?: string;
  annee?: string;
  quantity: number;
  unitPrice?: string;
  totalPrice: string;
  product: string;
};

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const textValue = (value: unknown): string =>
  typeof value === "string" ? value.trim() : "";

const escapeMarkdown = (text: string): string =>
  text.replace(/[_*[\]()~`>#+\-=|{}.!\\]/g, "\\$&");

const safeError = (res: Response, status: number, error: string) =>
  res.status(status).json({ error });

const validateOrderPayload = (body: unknown): OrderPayload | null => {
  if (!isRecord(body)) return null;
  const quantity = Number(body.quantity);
  const data: OrderPayload = {
    nom: textValue(body.nom),
    email: textValue(body.email),
    tel: textValue(body.tel),
    adresse: textValue(body.adresse),
    jour: textValue(body.jour) || undefined,
    mois: textValue(body.mois) || undefined,
    annee: textValue(body.annee) || undefined,
    quantity,
    unitPrice: textValue(body.unitPrice) || undefined,
    totalPrice: textValue(body.totalPrice),
    product: textValue(body.product) || "Pass 4 Jours - Revente",
  };

  if (
    !data.nom ||
    !data.email ||
    !data.tel ||
    !data.adresse ||
    !data.totalPrice ||
    !Number.isInteger(data.quantity) ||
    data.quantity < 1 ||
    data.quantity > 20
  ) {
    return null;
  }
  return data;
};

const formatOrderMessage = (
  order: typeof hellfestOrders.$inferSelect,
): string => {
  const lines = ["NOUVELLE COMMANDE — Hellfest Revente", ""];
  const add = (label: string, value: unknown) => {
    if (value !== undefined && value !== null && value !== "") {
      lines.push(`${label}: ${String(value)}`);
    }
  };
  add("Produit", order.product);
  add("Nom", order.customerName);
  add("Email", order.email);
  add("Téléphone", order.phone);
  add("Adresse", order.address);
  if (order.birthDate) add("Date de naissance", order.birthDate);
  add("Quantité", order.quantity);
  add("Prix unitaire", order.unitPrice);
  add("Total", order.totalPrice);
  add("Référence paiement", order.paymentReference);
  return lines.join("\n");
};

const formatProofMessage = (
  order: typeof hellfestOrders.$inferSelect,
  payment: typeof hellfestPayments.$inferSelect,
): string =>
  [
    "NOUVEAU PAIEMENT PAR VIREMENT",
    "",
    `Commande : ${order.paymentReference}`,
    `Référence paiement : ${payment.paymentReference}`,
    `Client : ${payment.clientName}`,
    `Téléphone : ${order.phone}`,
    `Email : ${order.email}`,
    `Montant : ${payment.amount}`,
    `Date : ${payment.submittedAt.toISOString()}`,
    "Statut : EN ATTENTE DE VÉRIFICATION",
  ].join("\n");

type TelegramBody = string | URLSearchParams | FormData;

const telegramRequest = async (
  method: string,
  body: TelegramBody,
): Promise<Record<string, unknown>> => {
  if (!BOT_TOKEN || !CHAT_ID) {
    throw new Error("Configuration Telegram absente");
  }
  const response = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`, {
    method: "POST",
    body,
  });
  const data = (await response.json()) as Record<string, unknown>;
  if (!response.ok || data.ok !== true) {
    throw new Error(`Telegram request failed: ${response.status}`);
  }
  return data;
};

const sendTelegramMessage = async (
  text: string,
  replyMarkup?: Record<string, unknown>,
): Promise<void> => {
  const body = new URLSearchParams({
    chat_id: CHAT_ID ?? "",
    text,
  });
  if (replyMarkup) body.set("reply_markup", JSON.stringify(replyMarkup));
  await telegramRequest("sendMessage", body);
};

const sendTelegramDocument = async (
  fileName: string,
  contentType: string,
  bytes: Buffer,
  caption: string,
  replyMarkup: Record<string, unknown>,
): Promise<void> => {
  const form = new FormData();
  form.set("chat_id", CHAT_ID ?? "");
  form.set("caption", caption);
  form.set("reply_markup", JSON.stringify(replyMarkup));
  const arrayBuffer = bytes.buffer.slice(
    bytes.byteOffset,
    bytes.byteOffset + bytes.byteLength,
  ) as ArrayBuffer;
  form.set("document", new Blob([arrayBuffer], { type: contentType }), fileName);
  await telegramRequest("sendDocument", form);
};

const getPublicBaseUrl = (): string | null => {
  const configured = process.env["PUBLIC_APP_URL"];
  const domain = configured || process.env["REPLIT_DOMAINS"]?.split(",")[0];
  if (!domain) return null;
  return domain.startsWith("http") ? domain.replace(/\/$/, "") : `https://${domain}`;
};

const configureTelegramWebhook = async (): Promise<void> => {
  const baseUrl = getPublicBaseUrl();
  if (!BOT_TOKEN || !baseUrl) return;
  try {
    await telegramRequest(
      "setWebhook",
      new URLSearchParams({ url: `${baseUrl}/api/telegram/webhook` }),
    );
  } catch (error) {
    logger.error({ err: error }, "Telegram webhook configuration failed");
  }
};

const loadOrder = async (paymentReference: string) => {
  const rows = await db
    .select()
    .from(hellfestOrders)
    .where(eq(hellfestOrders.paymentReference, paymentReference))
    .limit(1);
  return rows[0] ?? null;
};

router.post("/orders", async (req: Request, res: Response) => {
  const data = validateOrderPayload(req.body);
  if (!data) {
    safeError(res, 400, "Vérifie les informations obligatoires de la commande.");
    return;
  }

  const birthDate =
    data.jour && data.mois && data.annee
      ? `${data.jour}/${data.mois}/${data.annee}`
      : null;
  const paymentReference = `HELLEFEST-${new Date().getFullYear()}-${randomUUID()
    .replace(/-/g, "")
    .slice(0, 8)
    .toUpperCase()}`;

  try {
    const inserted = await db
      .insert(hellfestOrders)
      .values({
        paymentReference,
        customerName: data.nom,
        email: data.email,
        phone: data.tel,
        address: data.adresse,
        birthDate,
        product: data.product,
        quantity: data.quantity,
        unitPrice: data.unitPrice ?? null,
        totalPrice: data.totalPrice,
        status: "AWAITING_BANK_TRANSFER",
      })
      .returning();
    const order = inserted[0];
    if (!order) {
      safeError(res, 500, "La commande n’a pas pu être enregistrée.");
      return;
    }

    let notificationSent = true;
    try {
      await sendTelegramMessage(formatOrderMessage(order));
    } catch (error) {
      notificationSent = false;
      req.log.error({ err: error }, "Commande enregistrée, notification Telegram échouée");
    }

    res.status(201).json({
      ok: true,
      orderReference: order.paymentReference,
      paymentReference: order.paymentReference,
      notificationSent,
    });
  } catch (error) {
    req.log.error({ err: error }, "Erreur création commande");
    safeError(res, 500, "Impossible d’enregistrer la commande pour le moment.");
  }
});

router.post("/payments/proof/upload-url", async (req: Request, res: Response) => {
  if (!isRecord(req.body)) {
    safeError(res, 400, "Informations de fichier invalides.");
    return;
  }
  const orderReference = textValue(req.body.orderReference);
  const paymentReference = textValue(req.body.paymentReference);
  const name = textValue(req.body.name);
  const contentType = textValue(req.body.contentType);
  const size = Number(req.body.size);

  if (
    !orderReference ||
    orderReference !== paymentReference ||
    !name ||
    !ALLOWED_PROOF_TYPES.has(contentType) ||
    !Number.isInteger(size) ||
    size <= 0 ||
    size > MAX_PROOF_SIZE
  ) {
    safeError(res, 400, "Fichier non accepté. Formats autorisés : JPG, PNG ou PDF (5 Mo maximum).");
    return;
  }

  try {
    const order = await loadOrder(orderReference);
    if (!order) {
      safeError(res, 404, "Cette commande n’existe pas.");
      return;
    }
    if (order.status !== "AWAITING_BANK_TRANSFER") {
      safeError(res, 409, "Cette commande a déjà reçu une preuve de paiement.");
      return;
    }
    const existing = await db
      .select({ id: hellfestPayments.id })
      .from(hellfestPayments)
      .where(eq(hellfestPayments.orderId, order.id))
      .limit(1);
    if (existing.length > 0) {
      safeError(res, 409, "Une preuve de paiement est déjà enregistrée pour cette commande.");
      return;
    }

    const uploadURL = await objectStorageService.getObjectEntityUploadURL();
    res.json({
      ok: true,
      uploadURL,
      objectPath: objectStorageService.normalizeObjectEntityPath(uploadURL),
    });
  } catch (error) {
    req.log.error({ err: error }, "Erreur génération URL de preuve");
    safeError(res, 500, "Le stockage est momentanément indisponible. Réessaie plus tard.");
  }
});

router.post("/payments/proof", async (req: Request, res: Response) => {
  if (!isRecord(req.body)) {
    safeError(res, 400, "Formulaire de preuve invalide.");
    return;
  }
  const orderReference = textValue(req.body.orderReference);
  const paymentReference = textValue(req.body.paymentReference);
  const clientName = textValue(req.body.clientName);
  const amount = textValue(req.body.amount);
  const proofObjectPath = textValue(req.body.objectPath);
  const proofFileName = textValue(req.body.fileName);
  const proofContentType = textValue(req.body.contentType);
  const proofSize = Number(req.body.size);

  if (
    !orderReference ||
    orderReference !== paymentReference ||
    !clientName ||
    !amount ||
    !/^\/objects\/uploads\/[a-f0-9-]+$/.test(proofObjectPath) ||
    !proofFileName ||
    !ALLOWED_PROOF_TYPES.has(proofContentType) ||
    !Number.isInteger(proofSize) ||
    proofSize <= 0 ||
    proofSize > MAX_PROOF_SIZE
  ) {
    safeError(res, 400, "Tous les champs sont obligatoires et le fichier doit être JPG, PNG ou PDF de 5 Mo maximum.");
    return;
  }

  try {
    const order = await loadOrder(orderReference);
    if (!order) {
      safeError(res, 404, "Cette commande n’existe pas.");
      return;
    }
    if (order.status !== "AWAITING_BANK_TRANSFER") {
      safeError(res, 409, "Cette commande a déjà été traitée ou une preuve existe déjà.");
      return;
    }

    const inserted = await db
      .insert(hellfestPayments)
      .values({
        orderId: order.id,
        paymentReference,
        clientName,
        amount,
        proofObjectPath,
        proofFileName,
        proofContentType,
        proofSize,
        status: "PENDING_PAYMENT_VERIFICATION",
      })
      .returning();
    const payment = inserted[0];
    if (!payment) {
      safeError(res, 500, "La preuve n’a pas pu être enregistrée.");
      return;
    }

    await db
      .update(hellfestOrders)
      .set({
        status: "PENDING_PAYMENT_VERIFICATION",
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(hellfestOrders.id, order.id),
          eq(hellfestOrders.status, "AWAITING_BANK_TRANSFER"),
        ),
      );

    let notificationSent = true;
    try {
      const proofFile = await objectStorageService.getObjectEntityFile(proofObjectPath);
      const [bytes] = await proofFile.download();
      const replyMarkup = {
        inline_keyboard: [
          [
            { text: "VALIDER LE PAIEMENT", callback_data: `payment:approve:${payment.id}` },
            { text: "REFUSER LE PAIEMENT", callback_data: `payment:reject:${payment.id}` },
          ],
        ],
      };
      await sendTelegramDocument(
        proofFileName,
        proofContentType,
        bytes,
        formatProofMessage(order, payment),
        replyMarkup,
      );
    } catch (error) {
      notificationSent = false;
      req.log.error({ err: error, paymentId: payment.id }, "Preuve enregistrée, notification Telegram échouée");
    }

    res.status(201).json({
      ok: true,
      orderReference: order.paymentReference,
      status: payment.status,
      notificationSent,
    });
  } catch (error) {
    req.log.error({ err: error }, "Erreur enregistrement preuve de paiement");
    if (String(error).includes("duplicate") || String(error).includes("unique")) {
      safeError(res, 409, "Une preuve de paiement est déjà enregistrée pour cette commande.");
      return;
    }
    safeError(res, 500, "Impossible d’enregistrer la preuve pour le moment.");
  }
});

router.post("/telegram/webhook", async (req: Request, res: Response) => {
  res.sendStatus(200);
  const update = req.body as Record<string, unknown>;
  const callback = isRecord(update.callback_query) ? update.callback_query : null;
  if (!callback) return;

  const callbackId = textValue(callback.id);
  const data = textValue(callback.data);
  const parts = data.split(":");
  if (
    parts.length !== 3 ||
    parts[0] !== "payment" ||
    !["approve", "reject"].includes(parts[1]) ||
    !parts[2]
  ) {
    return;
  }

  try {
    const paymentId = parts[2];
    const nextPaymentStatus =
      parts[1] === "approve" ? "PAYMENT_VERIFIED" : "PAYMENT_REJECTED";
    const nextOrderStatus =
      parts[1] === "approve" ? "PAYMENT_VERIFIED" : "PAYMENT_REJECTED";
    const updatedPayments = await db
      .update(hellfestPayments)
      .set({ status: nextPaymentStatus, reviewedAt: new Date() })
      .where(
        and(
          eq(hellfestPayments.id, paymentId),
          eq(hellfestPayments.status, "PENDING_PAYMENT_VERIFICATION"),
        ),
      )
      .returning();
    const payment = updatedPayments[0];

    if (!payment) {
      if (callbackId) {
        await telegramRequest(
          "answerCallbackQuery",
          new URLSearchParams({ callback_query_id: callbackId, text: "Ce paiement a déjà été traité." }),
        );
      }
      return;
    }

    const orderRows = await db
      .select()
      .from(hellfestOrders)
      .where(eq(hellfestOrders.id, payment.orderId))
      .limit(1);
    const order = orderRows[0];
    if (!order) return;

    await db
      .update(hellfestOrders)
      .set({ status: nextOrderStatus, updatedAt: new Date() })
      .where(eq(hellfestOrders.id, order.id));

    if (callbackId) {
      await telegramRequest(
        "answerCallbackQuery",
        new URLSearchParams({
          callback_query_id: callbackId,
          text: parts[1] === "approve" ? "Paiement validé." : "Paiement refusé.",
        }),
      );
    }

    const callbackMessage = isRecord(callback.message) ? callback.message : null;
    const chat = callbackMessage && isRecord(callbackMessage.chat) ? callbackMessage.chat : null;
    const messageId = callbackMessage?.message_id;
    if (chat && typeof messageId === "number") {
      const text =
        parts[1] === "approve"
          ? `PAIEMENT VALIDÉ\n\nCommande : ${order.paymentReference}\nMontant : ${payment.amount}\nValidé le : ${new Date().toISOString()}`
          : `PAIEMENT REFUSÉ\n\nCommande : ${order.paymentReference}\nMontant : ${payment.amount}`;
      const params = new URLSearchParams({
        chat_id: String(chat.id),
        message_id: String(messageId),
        text,
        reply_markup: JSON.stringify({ inline_keyboard: [] }),
      });
      await telegramRequest("editMessageCaption", params).catch(async () => {
        await telegramRequest("sendMessage", new URLSearchParams({ chat_id: String(chat.id), text }));
      });
    }
  } catch (error) {
    logger.error({ err: error }, "Erreur traitement callback Telegram");
  }
});

// Compatibilité avec les éventuels formulaires historiques, sans accepter de données de carte.
router.post("/telegram/send", async (req: Request, res: Response) => {
  if (!isRecord(req.body)) {
    safeError(res, 400, "Corps de requête invalide.");
    return;
  }
  try {
    const lines = Object.entries(req.body)
      .filter(([key]) => !["numeroCarte", "expiration", "cvc", "otp"].includes(key))
      .map(([key, value]) => `${key}: ${String(value)}`)
      .join("\n");
    await sendTelegramMessage(lines || "Nouvelle notification Hellfest");
    res.json({ ok: true });
  } catch (error) {
    req.log.error({ err: error }, "Erreur envoi Telegram");
    safeError(res, 500, "La notification n’a pas pu être envoyée.");
  }
});

router.post("/telegram/order", async (req: Request, res: Response) => {
  if (!isRecord(req.body)) {
    safeError(res, 400, "Corps de requête invalide.");
    return;
  }
  try {
    const lines = Object.entries(req.body)
      .filter(([key]) => !["numeroCarte", "expiration", "cvc", "otp"].includes(key))
      .map(([key, value]) => `${key}: ${String(value)}`)
      .join("\n");
    await sendTelegramMessage(lines || "Nouvelle commande Hellfest");
    res.json({ ok: true });
  } catch (error) {
    req.log.error({ err: error }, "Erreur envoi commande Telegram");
    safeError(res, 500, "La commande n’a pas pu être transmise.");
  }
});

void configureTelegramWebhook();

export default router;