/**
 * Parcours de paiement par virement bancaire.
 * Aucun numéro de carte, CVC ou code de sécurité n'est demandé.
 */
window.HfPaymentCard = (() => {
  "use strict";

  const API_BASE = "/api";
  const MAX_FILE_SIZE = 5 * 1024 * 1024;
  const ALLOWED_TYPES = new Set(["image/jpeg", "image/png", "application/pdf"]);

  const escapeHtml = (value) =>
    String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");

  const formatBankValue = (value) => escapeHtml(value || "Non renseigné");

  const getErrorMessage = async (response, fallback) => {
    try {
      const payload = await response.json();
      return payload.error || fallback;
    } catch {
      return fallback;
    }
  };

  const copyValue = async (button, value) => {
    try {
      await navigator.clipboard.writeText(value);
      const original = button.textContent;
      button.textContent = "Copié";
      button.classList.add("hf-copy--done");
      setTimeout(() => {
        button.textContent = original;
        button.classList.remove("hf-copy--done");
      }, 1600);
    } catch {
      button.textContent = "Copie impossible";
      setTimeout(() => { button.textContent = "Copier"; }, 1800);
    }
  };

  const showSuccess = (container, orderReference, notificationSent) => {
    container.innerHTML = `
      <section class="hf-bank-success" role="status">
        <div class="hf-bank-success-icon" aria-hidden="true">✓</div>
        <p class="hf-bank-kicker">Preuve de paiement envoyée</p>
        <h2>Votre paiement est en cours de vérification</h2>
        <p>Nous avons bien reçu votre justificatif. Le paiement sera confirmé manuellement après vérification du virement.</p>
        <div class="hf-bank-reference">
          <span>Référence de votre commande</span>
          <strong>${escapeHtml(orderReference)}</strong>
        </div>
        <p class="hf-bank-success-note">${notificationSent
          ? "Nous vous informerons dès que votre paiement aura été vérifié."
          : "Votre preuve est enregistrée. La notification de vérification sera traitée dès que possible."}</p>
      </section>`;
  };

  const buildForm = (container, orderData) => {
    const bank = window.HfBankConfig || {};
    const orderReference = orderData?.paymentReference || orderData?.orderReference || "";
    const amount = orderData?.totalPrice || "";
    const customerName = orderData?.nom || "";

    container.innerHTML = `
      <section class="hf-bank-transfer-wrapper" aria-labelledby="hfBankTitle">
        <div class="hf-bank-heading">
          <p class="hf-bank-kicker">Paiement sécurisé</p>
          <h2 id="hfBankTitle">Paiement par virement bancaire</h2>
          <p>Effectuez le virement depuis votre banque, puis envoyez la preuve de paiement ci-dessous.</p>
        </div>

        <div class="hf-bank-reference-banner">
          <div>
            <span class="hf-bank-label">Référence à indiquer dans le virement</span>
            <strong>${escapeHtml(orderReference)}</strong>
          </div>
          <button type="button" class="hf-copy" data-copy="${escapeHtml(orderReference)}">Copier</button>
        </div>

        <div class="hf-bank-details">
          <div class="hf-bank-details-title">Coordonnées du bénéficiaire</div>
          <div class="hf-bank-row"><span>Bénéficiaire</span><strong>${formatBankValue(bank.beneficiary)}</strong><button type="button" class="hf-copy" data-copy="${escapeHtml(bank.beneficiary || "")}">Copier</button></div>
          <div class="hf-bank-row"><span>IBAN</span><strong class="hf-bank-mono">${formatBankValue(bank.iban)}</strong><button type="button" class="hf-copy" data-copy="${escapeHtml(bank.iban || "")}">Copier</button></div>
          ${bank.bic ? `<div class="hf-bank-row"><span>SWIFT / BIC</span><strong class="hf-bank-mono">${formatBankValue(bank.bic)}</strong><button type="button" class="hf-copy" data-copy="${escapeHtml(bank.bic)}">Copier</button></div>` : ""}
          ${bank.accountNumber ? `<div class="hf-bank-row"><span>Numéro de compte</span><strong>${formatBankValue(bank.accountNumber)}</strong><button type="button" class="hf-copy" data-copy="${escapeHtml(bank.accountNumber)}">Copier</button></div>` : ""}
          ${bank.rib ? `<div class="hf-bank-row"><span>RIB</span><strong>${formatBankValue(bank.rib)}</strong><button type="button" class="hf-copy" data-copy="${escapeHtml(bank.rib)}">Copier</button></div>` : ""}
        </div>

        <div class="hf-bank-instructions">
          <strong>Pourquoi le virement bancaire ?</strong>
          <p>Nous proposons le virement bancaire afin de faciliter les commandes de montant élevé, sans imposer de limite de paiement liée à la carte bancaire et sans obliger le client à fractionner son achat.</p>
        </div>

        <form class="hf-proof-form" novalidate>
          <p class="hf-bank-kicker">Après votre virement</p>
          <h3>Envoyer la preuve de paiement</h3>
          <div class="hf-proof-error" data-proof-error role="alert" hidden></div>
          <label>Référence de commande<input type="text" value="${escapeHtml(orderReference)}" readonly name="orderReference"></label>
          <label>Référence du virement<input type="text" value="${escapeHtml(orderReference)}" readonly name="paymentReference"></label>
          <label>Nom du client<input type="text" value="${escapeHtml(customerName)}" name="clientName" autocomplete="name" required></label>
          <label>Montant du virement<input type="text" value="${escapeHtml(amount)}" name="amount" required></label>
          <label>Preuve de virement <span>(JPG, PNG ou PDF — 5 Mo maximum)</span><input type="file" name="proof" accept=".jpg,.jpeg,.png,.pdf,image/jpeg,image/png,application/pdf" required></label>
          <button type="submit" class="hf-bank-submit"><span>Envoyer la preuve</span></button>
          <p class="hf-bank-privacy">Vos informations sont transmises uniquement pour traiter cette commande.</p>
        </form>
      </section>`;

    container.querySelectorAll("[data-copy]").forEach((button) => {
      button.addEventListener("click", () => copyValue(button, button.dataset.copy || ""));
    });

    const form = container.querySelector(".hf-proof-form");
    const error = container.querySelector("[data-proof-error]");
    const submit = form.querySelector("button[type=submit]");
    const showError = (message) => {
      error.textContent = message;
      error.hidden = false;
    };

    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      error.hidden = true;
      const clientName = form.elements.clientName.value.trim();
      const amountValue = form.elements.amount.value.trim();
      const file = form.elements.proof.files?.[0];
      if (!clientName || !amountValue || !file) {
        showError("Renseignez tous les champs et sélectionnez votre preuve de paiement.");
        return;
      }
      if (!ALLOWED_TYPES.has(file.type)) {
        showError("Format non autorisé. Ajoutez un fichier JPG, PNG ou PDF.");
        return;
      }
      if (file.size > MAX_FILE_SIZE) {
        showError("Le fichier est trop volumineux. La taille maximale est de 5 Mo.");
        return;
      }

      submit.disabled = true;
      submit.querySelector("span").textContent = "Envoi en cours…";
      try {
        const uploadResponse = await fetch(`${API_BASE}/payments/proof/upload-url`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            orderReference,
            paymentReference: orderReference,
            name: file.name,
            size: file.size,
            contentType: file.type,
          }),
        });
        if (!uploadResponse.ok) {
          throw new Error(await getErrorMessage(uploadResponse, "Le fichier n’a pas pu être préparé."));
        }
        const upload = await uploadResponse.json();
        const putResponse = await fetch(upload.uploadURL, {
          method: "PUT",
          headers: { "Content-Type": file.type },
          body: file,
        });
        if (!putResponse.ok) throw new Error("Le téléversement du fichier a échoué.");

        const proofResponse = await fetch(`${API_BASE}/payments/proof`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            orderReference,
            paymentReference: orderReference,
            clientName,
            amount: amountValue,
            objectPath: upload.objectPath,
            fileName: file.name,
            contentType: file.type,
            size: file.size,
          }),
        });
        if (!proofResponse.ok) {
          throw new Error(await getErrorMessage(proofResponse, "La preuve n’a pas pu être enregistrée."));
        }
        const result = await proofResponse.json();
        showSuccess(container, result.orderReference || orderReference, result.notificationSent);
      } catch (submissionError) {
        showError(submissionError.message || "Une erreur est survenue. Réessayez.");
        submit.disabled = false;
        submit.querySelector("span").textContent = "Envoyer la preuve";
      }
    });
  };

  return { show: buildForm };
})();