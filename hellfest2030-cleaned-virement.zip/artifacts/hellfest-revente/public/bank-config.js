/*
 * Coordonnées affichées publiquement sur la page de virement.
 * Ne jamais mettre de secret Telegram ou de clé privée dans ce fichier.
 */
window.HfBankConfig = Object.freeze({
  beneficiary: "BONNAMY LORIS",
  iban: "FR7614518292670010477404030",
  bic: "FTNOFRP1XXX",
  accountNumber: "",
  rib: "",
});
