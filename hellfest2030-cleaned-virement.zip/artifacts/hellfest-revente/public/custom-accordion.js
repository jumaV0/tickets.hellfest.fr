(() => {
  "use strict";

  const panelSelector =
    ".widget-section div[class*='grid-col'] > div > div:nth-child(4)";

  const findPanel = () => document.querySelector(panelSelector);

  const setPanelState = (panel, isOpen) => {
    panel.dataset.accordionOpen = String(isOpen);
    panel.setAttribute("aria-expanded", String(isOpen));
  };

  const isAccordionHeaderClick = (panel, event) => {
    const interactiveElement = event.target?.closest?.(
      "button, input, select, textarea, a, form"
    );
    if (interactiveElement) return false;

    const panelTop = panel.getBoundingClientRect().top;
    const clickPosition = event.clientY - panelTop;

    // The red PASS 4 JOURS banner is the first ~50px of the ticket panel.
    // Checking the position instead of the event target keeps all controls
    // below it independent from the accordion.
    return clickPosition >= 0 && clickPosition <= 58;
  };

  const setupAccordion = () => {
    const panel = findPanel();
    if (!panel || panel.dataset.accordionReady === "true") return;

    panel.dataset.accordionReady = "true";
    panel.setAttribute("tabindex", "0");
    panel.setAttribute("aria-label", "Contenu des billets");
    setPanelState(panel, true);

    panel.addEventListener("click", (event) => {
      if (!isAccordionHeaderClick(panel, event)) return;

      const isOpen = panel.dataset.accordionOpen !== "false";
      setPanelState(panel, !isOpen);
    });

    panel.addEventListener("keydown", (event) => {
      if (event.key !== "Enter" && event.key !== " ") return;
      if (event.target !== panel) return;

      event.preventDefault();
      const isOpen = panel.dataset.accordionOpen !== "false";
      setPanelState(panel, !isOpen);
    });
  };

  setupAccordion();
  new MutationObserver(setupAccordion).observe(document.body, {
    childList: true,
    subtree: true,
  });
})();