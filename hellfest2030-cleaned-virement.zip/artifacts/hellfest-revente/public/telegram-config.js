/*
 * Réglages de l'envoi Telegram
 * -----------------------------
 * Le token du bot et l'identifiant du canal restent côté serveur.
 * Ne les ajoutez jamais dans ce fichier ni dans le site public.
 *
 * Si votre site et l'API sont sur le même domaine, laissez "/api/orders".
 * Si l'API est hébergée ailleurs (ex : Render), remplacez apiUrl par l'URL complète :
 *   apiUrl: "https://votre-api.onrender.com/api/orders"
 */
window.HELLFEST_TELEGRAM_CONFIG = Object.freeze({
  apiUrl: "/api/orders",
  enabled: true,
});
